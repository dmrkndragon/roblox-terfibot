# MOSTERDEV

- **Kodlayan** YouTube: [MosterDev](https://www.youtube.com/@MosterDev)

TÜM SİSTEMLER ÇALIŞMAKTADIR. TÜM KONTROLLER EDİLDİ VE ÇALIŞIYOR.
> SİZLERİN TEK YAPMANIZ GEREKEN " npm install " KURMANIZ VE " .env " İÇERİĞİNİ DÜZELTMENİZ GEREKMEKTEDİR.

`.env İçeriğini doldurmanız gerekiyor.`

**BOTU BAŞLATMAK İÇİN**
`node deploy.js`
`node . `

**ÖNEMLİ UYARI !**
`BOT TAMAMEN YouTube/MosterDev AİTTİR İZİNSİZ PAYLAŞILMASI/SATIŞA SUNULMASI KESİNLİKLE YASAKTIR.`
